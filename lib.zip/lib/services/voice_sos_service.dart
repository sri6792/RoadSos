// lib/services/voice_sos_service.dart
//
// Continuously listens for trigger words ("SOS", "help", "accident",
// "emergency") and calls onVoiceSOSTriggered when detected.
//
// Usage:
//   VoiceSosService.instance.onTriggered = () { ... };
//   await VoiceSosService.instance.start();
//   VoiceSosService.instance.stop();
//
// The service auto-restarts listening after each session ends (speech_to_text
// stops after a period of silence, so we loop it).

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceSosService {
  // ── Singleton ──────────────────────────────────────────────────────────────
  static final VoiceSosService instance = VoiceSosService._();
  VoiceSosService._();

  // ── Trigger words (lowercase) ──────────────────────────────────────────────
  static const _keywords = [
    // English
    'sos', 'help', 'accident', 'emergency', 'call ambulance',
    // Hindi
    'bachao', 'madad', 'ambulance bulao', 'police bulao',
    // Marathi
    'vaachva', 'sahaay',
    // Tamil
    'udhavi', 'காப்பாற்று',
    // Telugu
    'sahayam',
  ];

  // ── Cooldown between triggers ──────────────────────────────────────────────
  static const _cooldown = Duration(seconds: 20);

  // ── State ──────────────────────────────────────────────────────────────────
  final SpeechToText _stt = SpeechToText();
  bool _isRunning = false;
  bool _isListening = false;
  bool _initialized = false;
  DateTime? _lastTriggered;
  Timer? _restartTimer;

  /// Set this before calling start().
  VoidCallback? onTriggered;

  /// Exposed so UI can show mic state.
  final ValueNotifier<bool> isListeningNotifier = ValueNotifier(false);

  // ── Public API ─────────────────────────────────────────────────────────────

  bool get isRunning => _isRunning;

  Future<bool> start() async {
    if (_isRunning) return true;

    // Initialize once
    if (!_initialized) {
      _initialized = await _stt.initialize(
        onError: (e) => debugPrint('VoiceSOS STT error: ${e.errorMsg}'),
        onStatus: (status) {
          debugPrint('VoiceSOS STT status: $status');
          // Auto-restart when STT goes idle
          if (status == 'done' || status == 'notListening') {
            _isListening = false;
            isListeningNotifier.value = false;
            if (_isRunning) {
              // Small delay before restarting to avoid hammering the mic
              _restartTimer = Timer(const Duration(seconds: 2), _listen);
            }
          }
        },
      );
    }

    if (!_initialized) {
      debugPrint('VoiceSOS: microphone not available');
      return false;
    }

    _isRunning = true;
    _listen();
    return true;
  }

  void stop() {
    _isRunning = false;
    _restartTimer?.cancel();
    _stt.stop();
    _isListening = false;
    isListeningNotifier.value = false;
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  void _listen() {
    if (!_isRunning || _isListening) return;
    _isListening = true;
    isListeningNotifier.value = true;

    _stt.listen(
      listenFor: const Duration(seconds: 10),
      pauseFor: const Duration(seconds: 4),
      onResult: (result) {
        final text = result.recognizedWords.toLowerCase();
        debugPrint('VoiceSOS heard: $text');
        if (_containsKeyword(text)) {
          _onKeywordDetected();
        }
      },
      cancelOnError: false,
      partialResults: true,
      localeId: 'en_IN',
      // Suppress the Google listening UI and sound
      listenMode: ListenMode.confirmation,
    );
  }

  bool _containsKeyword(String text) {
    return _keywords.any((kw) => text.contains(kw));
  }

  void _onKeywordDetected() {
    final now = DateTime.now();
    if (_lastTriggered != null &&
        now.difference(_lastTriggered!) < _cooldown) {
      return; // still in cooldown
    }
    _lastTriggered = now;
    debugPrint('VoiceSOS: keyword detected — triggering SOS');
    onTriggered?.call();
  }
}