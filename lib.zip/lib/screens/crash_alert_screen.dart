// lib/screens/crash_alert_screen.dart
//
// Shown immediately after a crash is detected.
// Counts down 10 seconds — if user doesn't cancel, navigates to SOSActiveScreen.
// Plays a loud alert sound via flutter_tts so even an injured user notices.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../theme/app_theme.dart';
import 'sos_active_screen.dart';

class CrashAlertScreen extends StatefulWidget {
  final int seconds;
  final String title;
  final String subtitle;
  const CrashAlertScreen({
    super.key,
    this.seconds = 10,
    this.title = 'Are you okay?',
    this.subtitle = 'A sudden impact was detected.\nSOS will be sent automatically.',
  });

  @override
  State<CrashAlertScreen> createState() => _CrashAlertScreenState();
}

class _CrashAlertScreenState extends State<CrashAlertScreen>
    with SingleTickerProviderStateMixin {
  late int _remaining;
  Timer? _timer;
  bool _cancelled = false;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;

  final FlutterTts _tts = FlutterTts();

  @override
  void initState() {
    super.initState();

    _remaining = widget.seconds;

    // Pulse animation for the countdown ring
    _pulseCtrl = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: 1.0, end: 1.08)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _startVoiceAlert();
    _startCountdown();
  }

  Future<void> _startVoiceAlert() async {
    await _tts.setLanguage('en-IN');
    await _tts.setSpeechRate(0.45);
    await _tts.setVolume(1.0);
    await _tts.speak(
      'Accident detected. SOS will be triggered in 10 seconds. '
          'Tap Cancel if you are safe.',
    );
  }

  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _remaining--);

      // Haptic every second
      HapticFeedback.mediumImpact();

      if (_remaining <= 0) {
        t.cancel();
        _triggerSOS();
      }
    });
  }

  void _triggerSOS() {
    if (!mounted || _cancelled) return;
    _tts.stop();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const SOSActiveScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  void _cancel() {
    _cancelled = true;
    _timer?.cancel();
    _tts.stop();
    _tts.speak("Okay. Stay safe.");
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseCtrl.dispose();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = _remaining / widget.seconds;

    return Scaffold(
      backgroundColor: const Color(0xFF1A0000),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const SizedBox(height: 48),

              // ── Header ──────────────────────────────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.sosRed.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(20),
                      border:
                      Border.all(color: AppColors.sosRed.withValues(alpha: 0.5)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded,
                            color: AppColors.sosRed, size: 16),
                        const SizedBox(width: 6),
                        Text(
                          'CRASH DETECTED',
                          style: GoogleFonts.rajdhani(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppColors.sosRed,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              Text(
                widget.title,
                style: GoogleFonts.rajdhani(
                  fontSize: 36,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),

              Text(
                widget.subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.white.withValues(alpha: 0.6),
                  height: 1.6,
                ),
                textAlign: TextAlign.center,
              ),

              const Spacer(),

              // ── Countdown ring ──────────────────────────────────────────────
              AnimatedBuilder(
                animation: _pulse,
                builder: (context, child) => Transform.scale(
                  scale: _pulse.value,
                  child: child,
                ),
                child: SizedBox(
                  width: 200,
                  height: 200,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Progress ring
                      SizedBox.expand(
                        child: CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 10,
                          backgroundColor:
                          AppColors.sosRed.withValues(alpha: 0.15),
                          valueColor: const AlwaysStoppedAnimation<Color>(
                              AppColors.sosRed),
                          strokeCap: StrokeCap.round,
                        ),
                      ),
                      // Number
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '$_remaining',
                            style: GoogleFonts.rajdhani(
                              fontSize: 80,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              height: 1,
                            ),
                          ),
                          Text(
                            'seconds',
                            style: GoogleFonts.inter(
                              fontSize: 13,
                              color: Colors.white.withValues(alpha: 0.5),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const Spacer(),

              // ── Cancel button ───────────────────────────────────────────────
              SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton(
                  onPressed: _cancel,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF1A0000),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                    elevation: 0,
                  ),
                  child: Text(
                    "I'm Safe — Cancel SOS",
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Trigger immediately option
              TextButton(
                onPressed: _triggerSOS,
                child: Text(
                  'Send SOS Now',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.sosRed,
                  ),
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}