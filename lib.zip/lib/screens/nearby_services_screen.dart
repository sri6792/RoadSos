// lib/screens/nearby_services_screen.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';

import '../theme/app_theme.dart';
import '../secrets.dart';

import 'package:url_launcher/url_launcher.dart';

class NearbyServicesScreen extends StatefulWidget {
  const NearbyServicesScreen({super.key});

  @override
  State<NearbyServicesScreen> createState() => _NearbyServicesScreenState();
}

class _NearbyServicesScreenState extends State<NearbyServicesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  int _selectedTab = 0;

  String currentAddress = 'Getting location...';
  bool loading = true;
  bool showingCached = false;

  double? currentLat;
  double? currentLng;

  List<dynamic> services = [];

  final _tabs = [
    (
      'Hospitals',
      Icons.local_hospital_rounded,
      AppColors.sosRed,
      'hospital clinic medical',
    ),
    (
      'Police',
      Icons.local_police_rounded,
      AppColors.navyDark,
      'police station',
    ),
    (
      'Towing',
      Icons.car_crash_rounded,
      AppColors.warning,
      'towing service roadside assistance',
    ),
    (
      'Mechanics',
      Icons.build_rounded,
      AppColors.info,
      'car repair mechanic garage',
    ),
  ];

  @override
  void initState() {
    super.initState();

    _tabCtrl = TabController(length: 4, vsync: this);
    _tabCtrl.addListener(() {
      if (!_tabCtrl.indexIsChanging) {
        setState(() => _selectedTab = _tabCtrl.index);
      }
    });

    _loadLocation();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadLocation() async {
    setState(() {
      loading = true;
      showingCached = false;
      services = [];
      currentAddress = 'Getting location...';
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        setState(() {
          currentAddress = 'Location off';
        });
        await _loadCachedServicesFromFirestore();
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          currentAddress = 'Permission denied';
        });
        await _loadCachedServicesFromFirestore();
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      currentLat = position.latitude;
      currentLng = position.longitude;

      await _loadAddress(position.latitude, position.longitude);
      await _fetchNearbyServices();
    } catch (e) {
      debugPrint('Location error: $e');
      setState(() {
        currentAddress = 'Offline data';
      });
      await _loadCachedServicesFromFirestore();
    }
  }

  Future<void> _loadAddress(double lat, double lng) async {
    try {
      final placemarks = await placemarkFromCoordinates(lat, lng);

      if (placemarks.isNotEmpty) {
        final place = placemarks.first;

        final area = place.subLocality?.isNotEmpty == true
            ? place.subLocality!
            : place.locality?.isNotEmpty == true
            ? place.locality!
            : place.name ?? 'Live Location';

        final state = place.administrativeArea ?? '';

        setState(() {
          currentAddress = '$area, $state';
        });
      }
    } catch (_) {
      setState(() {
        currentAddress = 'Live Location';
      });
    }
  }

  Future<void> _fetchNearbyServices() async {
    if (currentLat == null || currentLng == null) {
      await _loadCachedServicesFromFirestore();
      return;
    }

    setState(() {
      loading = true;
      showingCached = false;
      services = [];
    });

    final tab = _tabs[_selectedTab];
    final typeName = tab.$1;
    final keyword = tab.$4;

    final url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json'
        '?location=$currentLat,$currentLng'
        '&rankby=distance'
        '&keyword=$keyword'
        '&key=$googleApiKey';

    try {
      final response = await http.get(Uri.parse(url));
      final data = jsonDecode(response.body);

      final results = data['results'] ?? [];

      if (results.isEmpty) {
        await _loadCachedServicesFromFirestore();
        return;
      }

      setState(() {
        services = results;
        loading = false;
        showingCached = false;
      });

      for (final service in results.take(10)) {
        final placeId = service['place_id'];
        if (placeId == null) continue;

        await FirebaseFirestore.instance
            .collection('cached_services')
            .doc(placeId)
            .set({
              'name': service['name'] ?? '',
              'location': service['vicinity'] ?? '',
              'type': typeName,
              'keyword': keyword,
              'rating': service['rating'] ?? 0,
              'openNow': service['opening_hours']?['open_now'],
              'latitude': service['geometry']?['location']?['lat'],
              'longitude': service['geometry']?['location']?['lng'],
              'placeId': placeId,
              'source': 'google_places',
              'userLatitude': currentLat,
              'userLongitude': currentLng,
              'searchedFrom': currentAddress,
              'cachedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
      }

      debugPrint('Cached ${results.length} $typeName services to Firestore');
    } catch (e) {
      debugPrint('Nearby services error: $e');
      await _loadCachedServicesFromFirestore();
    }
  }

  Future<void> _loadCachedServicesFromFirestore() async {
    try {
      final typeName = _tabs[_selectedTab].$1;

      final snapshot = await FirebaseFirestore.instance
          .collection('cached_services')
          .where('type', isEqualTo: typeName)
          .limit(20)
          .get(const GetOptions(source: Source.cache));

      setState(() {
        services = snapshot.docs.map((doc) {
          return {'id': doc.id, ...doc.data(), 'fromCache': true};
        }).toList();

        loading = false;
        showingCached = true;
      });

      debugPrint('Loaded cached $typeName services from Firestore');
    } catch (e) {
      debugPrint('Cached Firestore error: $e');
      setState(() {
        loading = false;
        showingCached = true;
        services = [];
      });
    }
  }

  String _headerSubtitle() {
    if (showingCached) {
      return '$currentAddress · ';
    }

    return '$currentAddress · Showing live nearby services';
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.055).clamp(16.0, 28.0);

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: AppColors.white,
              padding: EdgeInsets.fromLTRB(pad, 16, pad, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'Nearby Services',
                        style: GoogleFonts.rajdhani(
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                          color: AppColors.navyDark,
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: _loadLocation,
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: AppColors.offWhite,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppColors.lightGray),
                          ),
                          child: const Icon(
                            Icons.my_location_rounded,
                            color: AppColors.sosRed,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        showingCached
                            ? Icons.cloud_off_rounded
                            : Icons.location_on_rounded,
                        size: 13,
                        color: showingCached
                            ? AppColors.warning
                            : AppColors.sosRed,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          _headerSubtitle(),
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            color: AppColors.midGray,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 44,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _tabs.length,
                      separatorBuilder: (context, snapshot) => const SizedBox(width: 8),
                      itemBuilder: (_, i) {
                        final tab = _tabs[i];
                        final isSelected = _selectedTab == i;

                        return GestureDetector(
                          onTap: () async {
                            setState(() {
                              _selectedTab = i;
                              loading = true;
                              services = [];
                            });

                            _tabCtrl.animateTo(i);

                            await _fetchNearbyServices();
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? tab.$3
                                  : tab.$3.withValues(alpha: 0.08),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                color: isSelected
                                    ? tab.$3
                                    : tab.$3.withValues(alpha: 0.2),
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  tab.$2,
                                  size: 14,
                                  color: isSelected ? AppColors.white : tab.$3,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  tab.$1,
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: isSelected
                                        ? AppColors.white
                                        : tab.$3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
            Expanded(
              child: loading
                  ? const Center(
                      child: CircularProgressIndicator(color: AppColors.sosRed),
                    )
                  : services.isEmpty
                  ? Center(
                      child: Text(
                        showingCached
                            ? 'No cached services found'
                            : 'No nearby services found',
                        style: GoogleFonts.inter(
                          color: AppColors.midGray,
                          fontSize: 14,
                        ),
                      ),
                    )
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(pad, 14, pad, 90),
                      itemCount: services.length,
                      itemBuilder: (_, i) {
                        final service = services[i];
                        final tab = _tabs[_selectedTab];

                        return _LiveServiceCard(
                          service: service,
                          icon: tab.$2,
                          color: tab.$3,
                          showingCached: showingCached,
                          currentLat: currentLat,
                          currentLng: currentLng,
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LiveServiceCard extends StatelessWidget {
  final dynamic service;
  final IconData icon;
  final Color color;
  final bool showingCached;
  final double? currentLat;
  final double? currentLng;

  const _LiveServiceCard({
    required this.service,
    required this.icon,
    required this.color,
    required this.showingCached,
    required this.currentLat,
    required this.currentLng,
  });

  Future<void> _openNavigation() async {
    final destLat =
        service['geometry']?['location']?['lat'] ?? service['latitude'];
    final destLng =
        service['geometry']?['location']?['lng'] ?? service['longitude'];

    if (destLat == null || destLng == null) return;

    String url;

    if (currentLat != null && currentLng != null) {
      url =
          'https://www.google.com/maps/dir/?api=1'
          '&origin=$currentLat,$currentLng'
          '&destination=$destLat,$destLng'
          '&travelmode=driving';
    } else {
      url =
          'https://www.google.com/maps/dir/?api=1'
          '&destination=$destLat,$destLng'
          '&travelmode=driving';
    }

    final uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = service['name'] ?? 'Service';

    final address =
        service['vicinity'] ?? service['location'] ?? 'Address unavailable';

    final rating = service['rating']?.toString() ?? 'N/A';

    final openNow = service['opening_hours']?['open_now'] ?? service['openNow'];

    return GestureDetector(
      onTap: _openNavigation,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.lightGray),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          name,
                          style: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppColors.navyDark,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    address,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: AppColors.midGray,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        size: 14,
                        color: AppColors.warning,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        rating,
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          color: AppColors.navyDark,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        openNow == true
                            ? 'Open now'
                            : openNow == false
                            ? 'Closed'
                            : 'Hours unknown',
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          color: openNow == true
                              ? AppColors.success
                              : AppColors.midGray,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.navigation_rounded,
              color: AppColors.midGray,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}
