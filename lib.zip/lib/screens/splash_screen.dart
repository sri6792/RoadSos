// lib/screens/splash_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _textOpacity;
  late Animation<Offset> _textSlide;
  late Animation<double> _taglineOpacity;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _logoScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack),
      ),
    );
    _logoOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );
    _textOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.4, 0.7, curve: Curves.easeOut),
      ),
    );
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _ctrl,
            curve: const Interval(0.4, 0.7, curve: Curves.easeOut),
          ),
        );
    _taglineOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.6, 1.0, curve: Curves.easeOut),
      ),
    );

    _ctrl.forward();

    Future.delayed(const Duration(milliseconds: 3200), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            pageBuilder:  (context, animation, secondaryAnimation) => const LoginScreen(),
            transitionsBuilder: (context, anim, secondaryAnimation, child) =>
                FadeTransition(opacity: anim, child: child),
            transitionDuration: const Duration(milliseconds: 600),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.navyDark,
      body: Stack(
        children: [
          // Background grid pattern
          CustomPaint(size: size, painter: _GridPainter()),
          // Red gradient overlay at bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: size.height * 0.4,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    AppColors.sosRed.withValues(alpha: 0.15),
                  ],
                ),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                AnimatedBuilder(
                  animation: _ctrl,
                  builder: (context, snapshot) => FadeTransition(
                    opacity: _logoOpacity,
                    child: ScaleTransition(
                      scale: _logoScale,
                      child: _SOSLogo(size: size.width * 0.32),
                    ),
                  ),
                ),
                SizedBox(height: size.height * 0.04),
                // App name
                AnimatedBuilder(
                  animation: _ctrl,
                  builder: (context, snapshot) => FadeTransition(
                    opacity: _textOpacity,
                    child: SlideTransition(
                      position: _textSlide,
                      child: Column(
                        children: [
                          Text(
                            'ROAD',
                            style: GoogleFonts.rajdhani(
                              fontSize: size.width * 0.16,
                              fontWeight: FontWeight.w800,
                              color: AppColors.white,
                              letterSpacing: 6,
                              height: 1,
                            ),
                          ),
                          Text(
                            'SOS',
                            style: GoogleFonts.rajdhani(
                              fontSize: size.width * 0.16,
                              fontWeight: FontWeight.w800,
                              color: AppColors.sosRed,
                              letterSpacing: 6,
                              height: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: size.height * 0.02),
                // Tagline
                AnimatedBuilder(
                  animation: _ctrl,
                  builder: (context, snapshot) => FadeTransition(
                    opacity: _taglineOpacity,
                    child: Column(
                      children: [
                        Container(
                          width: 40,
                          height: 2,
                          color: AppColors.sosRed.withValues(alpha: 0.6),
                          margin: const EdgeInsets.only(bottom: 12),
                        ),
                        Text(
                          'Help is one tap away',
                          style: GoogleFonts.inter(
                            fontSize: size.width * 0.038,
                            fontWeight: FontWeight.w400,
                            color: AppColors.white.withValues(alpha: 0.65),
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Bottom loading indicator
          Positioned(
            bottom: size.height * 0.08,
            left: 0,
            right: 0,
            child: AnimatedBuilder(
              animation: _taglineOpacity,
              builder: (context, snapshot) => Opacity(
                opacity: _taglineOpacity.value,
                child: Center(
                  child: SizedBox(
                    width: size.width * 0.3,
                    child: LinearProgressIndicator(
                      backgroundColor: AppColors.white.withValues(alpha: 0.1),
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        AppColors.sosRed,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SOSLogo extends StatelessWidget {
  final double size;
  const _SOSLogo({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.sosRed,
        boxShadow: [
          BoxShadow(
            color: AppColors.sosRed.withValues(alpha: 0.5),
            blurRadius: 40,
            spreadRadius: 10,
          ),
        ],
      ),
      child: Center(
        child: Icon(
          Icons.emergency_rounded,
          color: AppColors.white,
          size: size * 0.52,
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.03)
      ..strokeWidth = 1;

    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
