// lib/screens/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.055).clamp(16.0, 28.0);

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // Profile header
          SliverToBoxAdapter(
            child: Container(
              color: AppColors.white,
              child: SafeArea(
                bottom: false,
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: pad,
                        vertical: 16,
                      ),
                      child: Row(
                        children: [
                          Text(
                            'Profile',
                            style: GoogleFonts.rajdhani(
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                              color: AppColors.navyDark,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.offWhite,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColors.lightGray),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.edit_outlined,
                                  size: 14,
                                  color: AppColors.navyDark,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'Edit',
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.navyDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Profile card
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: pad),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [AppColors.navyDark, AppColors.navyLight],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            // Avatar
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                color: AppColors.sosRed,
                                borderRadius: BorderRadius.circular(18),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.sosRed.withValues(alpha: 0.4),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Text(
                                  'A',
                                  style: GoogleFonts.rajdhani(
                                    fontSize: 34,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.white,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Arjun Sharma',
                                    style: GoogleFonts.inter(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.white,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    '+91 98765 43210',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      color: AppColors.white.withValues(alpha: 0.7),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: AppColors.sosRed.withValues(alpha: 0.25),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: AppColors.sosRed.withValues(alpha: 0.4),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(
                                          Icons.bloodtype_rounded,
                                          size: 12,
                                          color: AppColors.sosRedLight,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          'Blood Group: B+',
                                          style: GoogleFonts.inter(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.sosRedLight,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(pad),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Medical Info
                  _ProfileSection(
                    title: 'Medical Info',
                    icon: Icons.medical_information_rounded,
                    color: AppColors.sosRed,
                    children: [
                      InfoRow(
                        label: 'Blood Group',
                        value: 'B+',
                        icon: Icons.bloodtype_rounded,
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      InfoRow(
                        label: 'Allergies',
                        value: 'Penicillin, Pollen',
                        icon: Icons.warning_amber_rounded,
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      InfoRow(
                        label: 'Conditions',
                        value: 'Mild Asthma',
                        icon: Icons.monitor_heart_rounded,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Vehicle Info
                  _ProfileSection(
                    title: 'Vehicle Info',
                    icon: Icons.directions_car_rounded,
                    color: AppColors.info,
                    children: [
                      InfoRow(
                        label: 'Vehicle',
                        value: 'Honda City - White',
                        icon: Icons.directions_car_filled_rounded,
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      InfoRow(
                        label: 'Registration',
                        value: 'GA 01 AB 1234',
                        icon: Icons.confirmation_number_rounded,
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      InfoRow(
                        label: 'Insurance',
                        value: 'HDFC Ergo · Exp: Mar 2026',
                        icon: Icons.security_rounded,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Settings
                  _ProfileSection(
                    title: 'Settings',
                    icon: Icons.settings_rounded,
                    color: AppColors.navyMid,
                    children: [
                      _SettingsRow(
                        icon: Icons.notifications_rounded,
                        label: 'Notifications',
                        trailing: Switch(
                          value: true,
                          onChanged: (_) {},
                          activeThumbColor: AppColors.sosRed,
                        ),
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      _SettingsRow(
                        icon: Icons.location_on_rounded,
                        label: 'Background Location',
                        trailing: Switch(
                          value: true,
                          onChanged: (_) {},
                          activeThumbColor: AppColors.sosRed,
                        ),
                      ),
                      const Divider(color: AppColors.lightGray, height: 1),
                      _SettingsRow(
                        icon: Icons.download_rounded,
                        label: 'Cache Offline Data',
                        trailing: Switch(
                          value: true,
                          onChanged: (_) {},
                          activeThumbColor: AppColors.sosRed,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Sign out
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: OutlinedButton.icon(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.logout_rounded,
                        color: AppColors.midGray,
                        size: 18,
                      ),
                      label: Text(
                        'Sign Out',
                        style: GoogleFonts.inter(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: AppColors.midGray,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.lightGray),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 90),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final List<Widget> children;

  const _ProfileSection({
    required this.title,
    required this.icon,
    required this.color,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.lightGray),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.05),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: color, size: 18),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.navyDark,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(children: children),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget trailing;

  const _SettingsRow({
    required this.icon,
    required this.label,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.offWhite,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 17, color: AppColors.navyMid),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: AppColors.navyDark,
              ),
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}
