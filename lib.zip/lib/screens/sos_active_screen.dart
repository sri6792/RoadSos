// lib/screens/sos_active_screen.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/sms_service.dart';
import '../theme/app_theme.dart';

String currentCallingService = 'No active call';

class SOSActiveScreen extends StatefulWidget {
  const SOSActiveScreen({super.key});

  @override
  State<SOSActiveScreen> createState() => _SOSActiveScreenState();
}

class _SOSActiveScreenState extends State<SOSActiveScreen>
    with TickerProviderStateMixin {
  int _countdown = 10;
  Timer? _timer;

  bool _callConnected = false;
  bool _smsSent = false;
  bool _locationShared = false;

  String liveAddress = 'Fetching live location...';
  String liveCoords = '';

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  final List<String> emergencyNumbers = [
    '+919999999999',
    '+918888888888',
  ];
  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(
      begin: 1.0,
      end: 1.08,
    ).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _activateRealSOS();

    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }

      setState(() {
        if (_countdown > 0) _countdown--;
      });
    });
  }


  Future<void> _activateRealSOS() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        setState(() => liveAddress = 'Location service is off');
        return;
      }

      LocationPermission permission =
      await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() => liveAddress = 'Location permission denied');
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      liveCoords =
      '${position.latitude.toStringAsFixed(6)}, ${position.longitude.toStringAsFixed(6)}';

      String address = 'Live location';

      try {
        final places = await placemarkFromCoordinates(
          position.latitude,
          position.longitude,
        );

        if (places.isNotEmpty) {
          final p = places.first;

          address =
          '${p.name ?? ''}, ${p.locality ?? ''}, ${p.administrativeArea ?? ''}';
        }
      } catch (_) {}

      setState(() {
        liveAddress = address;
        _locationShared = true;
      });

      final mapLink =
          'https://www.google.com/maps/search/?api=1&query=${position.latitude},${position.longitude}';

      final smsMessage = '''
🚨 ROADSOS EMERGENCY ALERT 🚨

Possible accident detected.

📍 Location:
$address

🗺 Coordinates:
$liveCoords

Google Maps:
$mapLink

Please respond immediately.
''';

      // SEND OFFLINE SMS
      final smsSuccess = await SMSService.sendSOS(
        numbers: emergencyNumbers,
        message: smsMessage,
      );

      setState(() {
        _smsSent = smsSuccess;
      });

      final sosData = {
        'type': 'sos_alert',
        'status': 'SOS Triggered',
        'latitude': position.latitude.toStringAsFixed(6),
        'longitude': position.longitude.toStringAsFixed(6),
        'address': address,
        'coordinates': liveCoords,
        'mapLink': mapLink,
        'smsStatus': smsSuccess ? 'sent' : 'failed',
        'callStatus': 'calling',
        'userId': 'abc123',
        'time': DateTime.now(),
        'createdAt': FieldValue.serverTimestamp(),
      };

      try {
        await FirebaseFirestore.instance
            .collection('sos_alerts')
            .add(sosData);

        await FirebaseFirestore.instance
            .collection('emergency_logs')
            .add(sosData);
      } catch (e) {
        debugPrint('Offline mode active: $e');
      }
    } catch (e) {
      debugPrint('SOS ERROR: $e');

      setState(() {
        liveAddress = 'Unable to share location';
        liveCoords = '';
      });
    }
  }


  Future<void> _logEmergencyNumberCall(String number, String label) async {
    setState(() {
      _callConnected = true;
      currentCallingService = '$label ($number)';
    });

    try {
      await FirebaseFirestore.instance.collection('emergency_logs').add({
        'type': 'emergency_number_call',
        'label': label,
        'number': number,
        'status': 'Calling',
        'callingText': 'Calling $label ($number)',
        'userId': 'abc123',
        'time': DateTime.now(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Call log will sync when online: $e');
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.06).clamp(18.0, 28.0);

    return Scaffold(
      backgroundColor: AppColors.navyDark,
      body: SafeArea(
        child: Stack(
          children: [
            CustomPaint(
              size: size,
              painter: _WavePainter(progress: _countdown / 10),
            ),
            Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'ROAD SOS',
                        style: GoogleFonts.rajdhani(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.white,
                          letterSpacing: 2,
                        ),
                      ),
                      TextButton(
                        onPressed: () => _showCancelDialog(),
                        style: TextButton.styleFrom(
                          backgroundColor: AppColors.white.withValues(
                            alpha: 0.1,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                        ),
                        child: Text(
                          'Cancel SOS',
                          style: GoogleFonts.inter(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (context, snapshot) => Transform.scale(
                    scale: _pulseAnim.value,
                    child: _PulseRing(countdown: _countdown),
                  ),
                ),

                const SizedBox(height: 24),

                Text(
                  'SOS ACTIVATED',
                  style: GoogleFonts.rajdhani(
                    fontSize: size.width * 0.09,
                    fontWeight: FontWeight.w800,
                    color: AppColors.white,
                    letterSpacing: 3,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  'Emergency services are being contacted',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: AppColors.white.withValues(alpha: 0.65),
                  ),
                ),

                const Spacer(),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: pad),
                  child: Column(
                    children: [
                      _StatusCard(
                        icon: Icons.call_rounded,
                        title: 'Emergency Call',
                        subtitle: 'Calling $currentCallingService',
                        status: _callConnected,
                        statusLabel: _callConnected
                            ? currentCallingService
                            : 'Calling...',
                      ),
                      const SizedBox(height: 10),
                      _StatusCard(
                        icon: Icons.notifications_active_rounded,
                        title: 'Emergency Response',
                        subtitle: _smsSent
                            ? 'Nearby emergency services notified'
                            : 'Contacting emergency response system...',
                        status: _smsSent,
                        statusLabel: _smsSent ? 'Alert Sent' : 'Sending...',
                      ),
                      const SizedBox(height: 10),
                      _StatusCard(
                        icon: Icons.location_on_rounded,
                        title: 'Live Location',
                        subtitle: '$liveAddress\n$liveCoords',
                        status: _locationShared,
                        statusLabel: _locationShared
                            ? 'Sharing'
                            : 'Fetching...',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: pad),
                  child: Row(
                    children: [
                      _QuickDial(
                        label: 'Ambulance',
                        number: '108',
                        color: AppColors.sosRed,
                        onLog: _logEmergencyNumberCall,
                      ),
                      const SizedBox(width: 10),
                      _QuickDial(
                        label: 'Police',
                        number: '100',
                        color: AppColors.navyLight,
                        onLog: _logEmergencyNumberCall,
                      ),
                      const SizedBox(width: 10),
                      _QuickDial(
                        label: 'Fire',
                        number: '101',
                        color: AppColors.warning,
                        onLog: _logEmergencyNumberCall,
                      ),
                    ],
                  ),
                ),

                SizedBox(height: size.height * 0.05),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showCancelDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Cancel SOS?',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w700,
            color: AppColors.navyDark,
          ),
        ),
        content: Text(
          'This will stop the emergency alert screen.',
          style: GoogleFonts.inter(color: AppColors.midGray),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Keep Active',
              style: GoogleFonts.inter(
                color: AppColors.sosRed,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text(
              'Cancel SOS',
              style: GoogleFonts.inter(color: AppColors.midGray),
            ),
          ),
        ],
      ),
    );
  }
}

class _PulseRing extends StatelessWidget {
  final int countdown;
  const _PulseRing({required this.countdown});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final ringSize = (size.width * 0.52).clamp(180.0, 240.0);

    return SizedBox(
      width: ringSize,
      height: ringSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: ringSize,
            height: ringSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: AppColors.sosRed.withValues(alpha: 0.2),
                width: 2,
              ),
            ),
          ),
          Container(
            width: ringSize * 0.8,
            height: ringSize * 0.8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: AppColors.sosRed.withValues(alpha: 0.4),
                width: 2,
              ),
            ),
          ),
          Container(
            width: ringSize * 0.62,
            height: ringSize * 0.62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.sosRed,
              boxShadow: [
                BoxShadow(
                  color: AppColors.sosRed.withValues(alpha: 0.6),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  countdown > 0 ? '$countdown' : '!',
                  style: GoogleFonts.rajdhani(
                    fontSize: ringSize * 0.26,
                    fontWeight: FontWeight.w800,
                    color: AppColors.white,
                    height: 1,
                  ),
                ),
                Text(
                  countdown > 0 ? 'seconds' : 'ACTIVE',
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    color: AppColors.white.withValues(alpha: 0.75),
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool status;
  final String statusLabel;

  const _StatusCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.statusLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.white.withValues(alpha: 0.1)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: status
                  ? AppColors.success.withValues(alpha: 0.15)
                  : AppColors.sosRed.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: status ? AppColors.success : AppColors.sosRedLight,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.white,
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    color: AppColors.white.withValues(alpha: 0.55),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: status
                  ? AppColors.success.withValues(alpha: 0.15)
                  : AppColors.sosRed.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              statusLabel,
              style: GoogleFonts.inter(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: status ? AppColors.success : AppColors.sosRedLight,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickDial extends StatelessWidget {
  final String label;
  final String number;
  final Color color;
  final Future<void> Function(String number, String label) onLog;

  const _QuickDial({
    required this.label,
    required this.number,
    required this.color,
    required this.onLog,
  });

  Future<void> _makeCall() async {
    await onLog(number, label);

    final uri = Uri.parse('tel:$number');

    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      debugPrint('Dialer error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: _makeCall,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.3)),
          ),
          child: Column(
            children: [
              Icon(Icons.call_rounded, color: color, size: 20),
              const SizedBox(height: 4),
              Text(
                number,
                style: GoogleFonts.rajdhani(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.white,
                ),
              ),
              Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 10,
                  color: AppColors.white.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double progress;
  _WavePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.sosRed.withValues(alpha: 0.05)
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height * 0.42);
    for (int i = 3; i >= 1; i--) {
      canvas.drawCircle(center, size.width * 0.25 * i, paint);
    }
  }

  @override
  bool shouldRepaint(_WavePainter old) => old.progress != progress;
}
