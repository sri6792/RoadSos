// lib/screens/home_screen.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:http/http.dart' as http;

import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../models/models.dart';
import '../secrets.dart';
import 'sos_active_screen.dart';

import 'package:url_launcher/url_launcher.dart';
import 'nearby_services_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'main_shell.dart';
import '../services/cache_service.dart';
import '../services/connectivity_service.dart';

class HomeScreen extends StatefulWidget {
  final bool isGuest;
  const HomeScreen({super.key, this.isGuest = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isOffline = false;
  String _cacheLabel = '';

  Future<void> _loadCachedHospitals() async {
    final cached = CacheService.instance.getServices(ServiceType.hospital);
    if (cached.isNotEmpty) {
      setState(() {
        nearbyHospitals = cached
            .take(3)
            .map((s) => {
          'name': s.name,
          'vicinity': s.address,
          'geometry': {
            'location': {'lat': s.lat, 'lng': s.lng}
          },
        })
            .toList();
        _cacheLabel = CacheService.instance.lastUpdatedLabel(ServiceType.hospital);
        hospitalsLoading = false;
      });
    } else {
      setState(() => hospitalsLoading = false);
    }
  }

  String currentAddress = 'Getting location...';

  LatLng? currentLatLng;
  bool mapLoading = true;

  List<dynamic> nearbyHospitals = [];
  bool hospitalsLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCurrentLocation();
  }

  Future<void> _openHospitalNavigation(dynamic hospital) async {
    final destLat = hospital['geometry']?['location']?['lat'];
    final destLng = hospital['geometry']?['location']?['lng'];

    if (destLat == null || destLng == null) return;

    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1'
          '&origin=${currentLatLng?.latitude},${currentLatLng?.longitude}'
          '&destination=$destLat,$destLng'
          '&travelmode=driving',
    );

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _loadCurrentLocation() async {
    setState(() {
      mapLoading = true;
      hospitalsLoading = true;
      nearbyHospitals = [];
      currentAddress = 'Getting location...';
    });
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        setState(() {
          currentAddress = 'Location off';
          mapLoading = false;
          hospitalsLoading = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          currentAddress = 'Permission denied';
          mapLoading = false;
          hospitalsLoading = false;
        });
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      final userLocation = LatLng(position.latitude, position.longitude);

      setState(() {
        currentLatLng = userLocation;
        mapLoading = false;
      });

      await _loadAddress(position.latitude, position.longitude);
      await _fetchNearbyHospitals(position.latitude, position.longitude);
    } catch (e) {
      setState(() {
        currentAddress = 'Location unavailable';
        mapLoading = false;
        hospitalsLoading = false;
      });
    }
  }

  Future<void> _loadAddress(double lat, double lng) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lng);

      if (placemarks.isNotEmpty) {
        final place = placemarks.first;

        String area = place.subLocality?.isNotEmpty == true
            ? place.subLocality!
            : place.locality?.isNotEmpty == true
            ? place.locality!
            : place.name ?? 'Unknown';

        String state = place.administrativeArea ?? '';

        setState(() {
          currentAddress = '$area, $state';
        });
      }
    } catch (e) {
      setState(() {
        currentAddress = 'Live Location';
      });
    }
  }

  Future<void> _fetchNearbyHospitals(double lat, double lng) async {
    // If offline, go straight to Hive cache
    if (!ConnectivityService.instance.isOnline) {
      setState(() => _isOffline = true);
      await _loadCachedHospitals();
      return;
    }

    final url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json'
        '?location=$lat,$lng'
        '&rankby=distance'
        '&keyword=hospital clinic medical'
        '&key=$googleApiKey';

    try {
      final response = await http.get(Uri.parse(url));

      debugPrint('Places response: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final results = data['results'] as List? ?? [];

        // Save live results to Hive for future offline use
        await CacheService.instance.saveFromPlacesResults(
          results,
          ServiceType.hospital,
        );

        setState(() {
          nearbyHospitals = results;
          _isOffline = false;
          _cacheLabel = '';
          hospitalsLoading = false;
        });
      } else {
        setState(() => hospitalsLoading = false);
      }
    } catch (e) {
      debugPrint('Places error: $e');
      setState(() => _isOffline = true);
      await _loadCachedHospitals();
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.055).clamp(16.0, 28.0);
    final isSmall = size.height < 700;

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: isSmall ? 80 : 90,
            floating: true,
            snap: true,
            backgroundColor: AppColors.white,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              background: SafeArea(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: pad, vertical: 12),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Good Morning,',
                            style: GoogleFonts.inter(
                              fontSize: 12,
                              color: AppColors.midGray,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          Text(
                            widget.isGuest ? 'Guest' : 'Arjun Sharma',
                            style: GoogleFonts.rajdhani(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: AppColors.navyDark,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.offWhite,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: AppColors.lightGray),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.location_on_rounded,
                                size: 14,
                                color: AppColors.sosRed,
                              ),
                              const SizedBox(width: 4),
                              Flexible(
                                child: Text(
                                  currentAddress,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.inter(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.navyDark,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Offline banner ─────────────────────────────────────────────────────
          SliverToBoxAdapter(
            child: ValueListenableBuilder<bool>(
              valueListenable: ConnectivityService.instance.notifier,
              builder: (context, isOnline, _) {
                if (isOnline && !_isOffline) return const SizedBox.shrink();
                return Container(
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF3CD),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFFFCA28)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.wifi_off_rounded,
                          color: Color(0xFF7B5800), size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'You are offline',
                              style: GoogleFonts.inter(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF7B5800),
                              ),
                            ),
                            if (_cacheLabel.isNotEmpty)
                              Text(
                                'Showing cached data · Updated \$_cacheLabel',
                                style: GoogleFonts.inter(
                                  fontSize: 11,
                                  color: const Color(0xFF7B5800),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: pad),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: isSmall ? 16 : 22),

                  _SOSButton(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const SOSActiveScreen(),
                        ),
                      );
                    },
                  ),

                  SizedBox(height: isSmall ? 18 : 24),

                  _MapPreview(
                    latLng: currentLatLng,
                    loading: mapLoading,
                    onRefresh: _loadCurrentLocation,
                  ),

                  SizedBox(height: isSmall ? 16 : 22),

                  const SectionHeader(title: 'Quick Actions'),
                  const SizedBox(height: 12),
                  _QuickActionsGrid(),

                  SizedBox(height: isSmall ? 16 : 22),

                  SectionHeader(
                    title: 'Nearby Hospitals',
                    actionLabel: 'See All →',
                    onAction: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const MainShell(initialIndex: 1),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),

                  if (hospitalsLoading)
                    const Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(
                        child: CircularProgressIndicator(
                          color: AppColors.sosRed,
                        ),
                      ),
                    )
                  else if (nearbyHospitals.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Center(
                        child: Text(
                          'No nearby hospitals found',
                          style: GoogleFonts.inter(color: AppColors.midGray),
                        ),
                      ),
                    )
                  else
                    ...nearbyHospitals.take(3).map((hospital) {
                      return GestureDetector(
                        onTap: () => _openHospitalNavigation(hospital),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: AppColors.sosRed.withValues(
                                    alpha: 0.1,
                                  ),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(
                                  Icons.local_hospital_rounded,
                                  color: AppColors.sosRed,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      hospital['name'] ?? 'Hospital',
                                      style: GoogleFonts.inter(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.navyDark,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      hospital['vicinity'] ?? hospital['location'] ?? '',
                                      style: GoogleFonts.inter(
                                        fontSize: 12,
                                        color: AppColors.midGray,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Icon(
                                Icons.navigation_rounded,
                                color: AppColors.midGray,
                                size: 20,
                              ),
                            ],
                          ),
                        ),
                      );
                    }),

                  const SizedBox(height: 90),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SOSButton extends StatefulWidget {
  final VoidCallback onTap;
  const _SOSButton({required this.onTap});

  @override
  State<_SOSButton> createState() => _SOSButtonState();
}

class _SOSButtonState extends State<_SOSButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulseAnim;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(
      begin: 1.0,
      end: 1.05,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final btnSize = (size.width * 0.46).clamp(170.0, 220.0);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        color: AppColors.navyDark,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.navyDark.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Emergency SOS',
            style: GoogleFonts.rajdhani(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppColors.white.withValues(alpha: 0.6),
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (context, snapshot) => Transform.scale(
              scale: _isPressed ? 0.95 : _pulseAnim.value,
              child: GestureDetector(
                onTapDown: (_) => setState(() => _isPressed = true),
                onTapUp: (_) {
                  setState(() => _isPressed = false);
                  widget.onTap();
                },
                onTapCancel: () => setState(() => _isPressed = false),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: btnSize,
                      height: btnSize,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.sosRed.withValues(alpha: 0.12),
                      ),
                    ),
                    Container(
                      width: btnSize * 0.84,
                      height: btnSize * 0.84,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.sosRed.withValues(alpha: 0.2),
                      ),
                    ),
                    Container(
                      width: btnSize * 0.7,
                      height: btnSize * 0.7,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.sosRed,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.sosRed.withValues(alpha: 0.5),
                            blurRadius: 24,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.emergency_rounded,
                            color: AppColors.white,
                            size: 36,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'SOS',
                            style: GoogleFonts.rajdhani(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                              color: AppColors.white,
                              letterSpacing: 3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Press & hold to send emergency alert',
            style: GoogleFonts.inter(
              fontSize: 12,
              color: AppColors.white.withValues(alpha: 0.45),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapPreview extends StatelessWidget {
  final LatLng? latLng;
  final bool loading;
  final VoidCallback onRefresh;

  const _MapPreview({
    required this.latLng,
    required this.loading,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFFE5E8ED),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            if (loading)
              const Center(
                child: CircularProgressIndicator(color: AppColors.sosRed),
              )
            else if (latLng == null)
              Center(
                child: Text(
                  'Unable to load map',
                  style: GoogleFonts.inter(
                    color: AppColors.navyDark,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              )
            else
              GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: latLng!,
                  zoom: 16,
                ),
                myLocationEnabled: true,
                myLocationButtonEnabled: false,
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
                markers: {
                  Marker(
                    markerId: const MarkerId('current_location'),
                    position: latLng!,
                    infoWindow: const InfoWindow(title: 'Your Live Location'),
                  ),
                },
              ),

            Positioned(
              right: 12,
              top: 12,
              child: GestureDetector(
                onTap: onRefresh,
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.my_location_rounded,
                    color: AppColors.sosRed,
                    size: 20,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActionsGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    final actions = [
      (Icons.local_hospital_rounded, 'Call\nAmbulance', AppColors.sosRed),
      (Icons.local_police_rounded, 'Call\nPolice', AppColors.navyMid),
      (Icons.share_location_rounded, 'Share\nLocation', AppColors.info),
      (Icons.car_crash_rounded, 'Call\nTowing', AppColors.warning),
    ];

    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      childAspectRatio: size.width < 360 ? 0.62 : 0.68,
      children: actions
          .map(
            (a) => QuickActionCard(
          icon: a.$1,
          label: a.$2,
          color: a.$3,
          onTap: () {},
        ),
      )
          .toList(),
    );
  }
}