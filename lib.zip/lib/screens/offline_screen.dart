// lib/screens/offline_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../models/models.dart';

class OfflineScreen extends StatefulWidget {
  const OfflineScreen({super.key});

  @override
  State<OfflineScreen> createState() => _OfflineScreenState();
}

class _OfflineScreenState extends State<OfflineScreen> {
  int _expandedTip = -1;

  final List<Map<String, String>> _firstAidTips = [
    {
      'title': 'Unconscious Person',
      'icon': '🧠',
      'steps':
          '1. Check surroundings for safety\n2. Call 112 immediately\n3. Place in recovery position\n4. Monitor breathing\n5. Do not give food/water',
    },
    {
      'title': 'Severe Bleeding',
      'icon': '🩸',
      'steps':
          '1. Apply firm pressure with clean cloth\n2. Elevate the wound if possible\n3. Do not remove cloth — add more if soaked\n4. Keep person calm and warm\n5. Seek medical help immediately',
    },
    {
      'title': 'Vehicle Accident',
      'icon': '🚗',
      'steps':
          '1. Do not move injured persons unless in danger\n2. Turn off vehicle ignition\n3. Switch on hazard lights\n4. Call 112 and 1033 (Road helpline)\n5. Keep bystanders away',
    },
    {
      'title': 'Choking',
      'icon': '😮',
      'steps':
          '1. Encourage coughing\n2. Give 5 firm back blows between shoulder blades\n3. If no improvement, give 5 abdominal thrusts\n4. Alternate back blows and thrusts\n5. Call 112 if unconscious',
    },
    {
      'title': 'Chest Pain',
      'icon': '❤️',
      'steps':
          '1. Have person sit or lie comfortably\n2. Loosen tight clothing\n3. Give aspirin if available and not allergic\n4. Call 112 immediately\n5. Begin CPR if unconscious and not breathing',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.055).clamp(16.0, 28.0);

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // Offline banner header
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: AppColors.navyDark,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(pad, 16, pad, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Status bar
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.warning.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: AppColors.warning.withValues(alpha: 0.4),
                              ),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.wifi_off_rounded,
                                  color: AppColors.warning,
                                  size: 14,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'OFFLINE MODE',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.warning,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          TextButton.icon(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.refresh_rounded,
                              size: 14,
                              color: AppColors.white,
                            ),
                            label: Text(
                              'Retry',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                color: AppColors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No Internet',
                        style: GoogleFonts.rajdhani(
                          fontSize: 30,
                          fontWeight: FontWeight.w700,
                          color: AppColors.white,
                          height: 1,
                        ),
                      ),
                      Text(
                        'Connection',
                        style: GoogleFonts.rajdhani(
                          fontSize: 30,
                          fontWeight: FontWeight.w700,
                          color: AppColors.sosRed,
                          height: 1,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Cached data is shown. SMS SOS still works.',
                        style: GoogleFonts.inter(
                          fontSize: 13,
                          color: AppColors.white.withValues(alpha: 0.6),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // SMS SOS button
                      GestureDetector(
                        onTap: () {},
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: AppColors.sosRed,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.sosRed.withValues(alpha: 0.4),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.sms_rounded,
                                color: AppColors.white,
                                size: 22,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                'Send SMS SOS',
                                style: GoogleFonts.inter(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: pad, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Emergency numbers
                  const SectionHeader(title: 'Emergency Numbers'),
                  const SizedBox(height: 12),
                  _EmergencyNumbersGrid(),
                  const SizedBox(height: 22),

                  // Cached services
                  SectionHeader(
                    title: 'Cached Nearby Services',
                    actionLabel: 'Updated 2h ago',
                  ),
                  const SizedBox(height: 12),
                  ...SampleData.hospitals
                      .take(2)
                      .map(
                        (s) => ServiceListItem(
                          service: s,
                          onCall: () {},
                          onNavigate: () {},
                        ),
                      ),
                  const SizedBox(height: 22),

                  // First Aid Tips
                  const SectionHeader(title: 'First Aid Tips'),
                  const SizedBox(height: 12),
                  ..._firstAidTips.asMap().entries.map(
                    (e) => _FirstAidTile(
                      tip: e.value,
                      isExpanded: _expandedTip == e.key,
                      onTap: () => setState(() {
                        _expandedTip = _expandedTip == e.key ? -1 : e.key;
                      }),
                    ),
                  ),

                  const SizedBox(height: 90),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmergencyNumbersGrid extends StatelessWidget {
  final List<Map<String, dynamic>> _numbers = [
    {
      'label': 'Emergency',
      'number': '112',
      'icon': Icons.sos_rounded,
      'color': AppColors.sosRed,
    },
    {
      'label': 'Ambulance',
      'number': '108',
      'icon': Icons.local_hospital_rounded,
      'color': AppColors.sosRedLight,
    },
    {
      'label': 'Police',
      'number': '100',
      'icon': Icons.local_police_rounded,
      'color': AppColors.navyMid,
    },
    {
      'label': 'Fire',
      'number': '101',
      'icon': Icons.local_fire_department_rounded,
      'color': AppColors.warning,
    },
    {
      'label': 'Women Help',
      'number': '1091',
      'icon': Icons.woman_rounded,
      'color': Color(0xFF9C27B0),
    },
    {
      'label': 'Road Help',
      'number': '1033',
      'icon': Icons.car_repair_rounded,
      'color': AppColors.info,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.1,
      children: _numbers.map((n) {
        final color = n['color'] as Color;
        return GestureDetector(
          onTap: () {},
          child: Container(
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: color.withValues(alpha: 0.2)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(n['icon'] as IconData, color: color, size: 24),
                const SizedBox(height: 6),
                Text(
                  n['number'] as String,
                  style: GoogleFonts.rajdhani(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: AppColors.navyDark,
                  ),
                ),
                Text(
                  n['label'] as String,
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    color: AppColors.midGray,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _FirstAidTile extends StatelessWidget {
  final Map<String, String> tip;
  final bool isExpanded;
  final VoidCallback onTap;

  const _FirstAidTile({
    required this.tip,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isExpanded
                ? AppColors.sosRed.withValues(alpha: 0.3)
                : AppColors.lightGray,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Text(tip['icon']!, style: const TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      tip['title']!,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.navyDark,
                      ),
                    ),
                  ),
                  Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    color: AppColors.midGray,
                  ),
                ],
              ),
            ),
            if (isExpanded)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.offWhite,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    tip['steps']!,
                    style: GoogleFonts.inter(
                      fontSize: 13,
                      color: AppColors.navyMid,
                      height: 1.7,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
