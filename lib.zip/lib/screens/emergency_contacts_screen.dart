// lib/screens/emergency_contacts_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../models/models.dart';

class EmergencyContactsScreen extends StatefulWidget {
  const EmergencyContactsScreen({super.key});

  @override
  State<EmergencyContactsScreen> createState() =>
      _EmergencyContactsScreenState();
}

class _EmergencyContactsScreenState extends State<EmergencyContactsScreen> {
  List<EmergencyContact> _contacts = List.from(SampleData.contacts);
  final List<Map<String, String>> _nationalContacts = [
    {
      "title": "Police",
      "number": "100",
      "icon": "👮",
    },
    {
      "title": "Ambulance",
      "number": "108",
      "icon": "🚑",
    },
    {
      "title": "Fire Brigade",
      "number": "101",
      "icon": "🔥",
    },
    {
      "title": "Women Helpline",
      "number": "1091",
      "icon": "🛡",
    },
  ];
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = (size.width * 0.055).clamp(16.0, 28.0);

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            // Header
            SliverToBoxAdapter(
              child: Container(
                color: AppColors.white,
                padding: EdgeInsets.fromLTRB(pad, 16, pad, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Emergency',
                              style: GoogleFonts.rajdhani(
                                fontSize: 26,
                                fontWeight: FontWeight.w700,
                                color: AppColors.navyDark,
                                height: 1,
                              ),
                            ),
                            Text(
                              'Contacts',
                              style: GoogleFonts.rajdhani(
                                fontSize: 26,
                                fontWeight: FontWeight.w700,
                                color: AppColors.sosRed,
                                height: 1,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () => _showAddContactSheet(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 9,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.sosRed,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.add_rounded,
                                  color: AppColors.white,
                                  size: 16,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'Add',
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${_contacts.length} contacts · Alerted when SOS is activated',
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        color: AppColors.midGray,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Contacts list
                    ..._contacts.map(
                      (c) => _ContactCard(
                        contact: c,
                        onSetPrimary: () => _setPrimary(c.id),
                        onDelete: () => _delete(c.id),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Medical Info section
                    const SizedBox(height: 20),

                    Text(
                      'National Emergency Numbers',
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.navyDark,
                      ),
                    ),

                    const SizedBox(height: 12),

                    ..._nationalContacts.map(
                          (item) => Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: AppColors.lightGray,
                          ),
                        ),
                        child: Row(
                          children: [
                            Text(
                              item['icon']!,
                              style: const TextStyle(fontSize: 24),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title']!,
                                    style: GoogleFonts.inter(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.navyDark,
                                    ),
                                  ),
                                  Text(
                                    item['number']!,
                                    style: GoogleFonts.inter(
                                      fontSize: 12,
                                      color: AppColors.midGray,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color:
                                AppColors.sosRed.withOpacity(0.08),
                                borderRadius:
                                BorderRadius.circular(12),
                              ),
                              child: const Icon(
                                Icons.call_rounded,
                                color: AppColors.sosRed,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    _MedicalInfoCard(),

                    const SizedBox(height: 90),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _setPrimary(String id) {
    setState(() {
      _contacts = _contacts
          .map(
            (c) => EmergencyContact(
              id: c.id,
              name: c.name,
              phone: c.phone,
              relation: c.relation,
              isPrimary: c.id == id,
            ),
          )
          .toList();
    });
  }

  void _delete(String id) {
    setState(() => _contacts.removeWhere((c) => c.id == id));
  }

  void _showAddContactSheet(BuildContext ctx) {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final relCtrl = TextEditingController();

    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.lightGray,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Add Emergency Contact',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.navyDark,
                ),
              ),
              const SizedBox(height: 20),
              _LabeledField(
                label: 'Full Name',
                ctrl: nameCtrl,
                hint: 'Priya Sharma',
              ),
              const SizedBox(height: 14),
              _LabeledField(
                label: 'Phone Number',
                ctrl: phoneCtrl,
                hint: '+91 98765 43210',
                keyboard: TextInputType.phone,
              ),
              const SizedBox(height: 14),
              _LabeledField(
                label: 'Relation',
                ctrl: relCtrl,
                hint: 'Spouse / Parent / Friend',
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: () {
                    if (nameCtrl.text.isNotEmpty) {
                      setState(() {
                        _contacts.add(
                          EmergencyContact(
                            id: DateTime.now().toString(),
                            name: nameCtrl.text,
                            phone: phoneCtrl.text,
                            relation: relCtrl.text,
                          ),
                        );
                      });
                      Navigator.pop(ctx);
                    }
                  },
                  child: const Text('Save Contact'),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class _ContactCard extends StatelessWidget {
  final EmergencyContact contact;
  final VoidCallback onSetPrimary;
  final VoidCallback onDelete;

  const _ContactCard({
    required this.contact,
    required this.onSetPrimary,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: contact.isPrimary
              ? AppColors.sosRed.withValues(alpha: 0.3)
              : AppColors.lightGray,
          width: contact.isPrimary ? 1.5 : 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // Avatar
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: contact.isPrimary
                    ? AppColors.sosRed.withValues(alpha: 0.1)
                    : AppColors.offWhite,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: contact.isPrimary
                      ? AppColors.sosRed.withValues(alpha: 0.2)
                      : AppColors.lightGray,
                ),
              ),
              child: Center(
                child: Text(
                  contact.name.substring(0, 1),
                  style: GoogleFonts.rajdhani(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: contact.isPrimary
                        ? AppColors.sosRed
                        : AppColors.navyDark,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        contact.name,
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.navyDark,
                        ),
                      ),
                      if (contact.isPrimary) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.sosRed.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            'Primary',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: AppColors.sosRed,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    contact.phone,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: AppColors.navyMid,
                    ),
                  ),
                  Text(
                    contact.relation,
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      color: AppColors.midGray,
                    ),
                  ),
                ],
              ),
            ),
            // Actions
            Column(
              children: [
                GestureDetector(
                  onTap: onSetPrimary,
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: contact.isPrimary
                          ? AppColors.sosRed.withValues(alpha: 0.1)
                          : AppColors.offWhite,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: contact.isPrimary
                            ? AppColors.sosRed.withValues(alpha: 0.3)
                            : AppColors.lightGray,
                      ),
                    ),
                    child: Icon(
                      contact.isPrimary
                          ? Icons.star_rounded
                          : Icons.star_outline_rounded,
                      size: 16,
                      color: contact.isPrimary
                          ? AppColors.sosRed
                          : AppColors.midGray,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: onDelete,
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: AppColors.offWhite,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.lightGray),
                    ),
                    child: const Icon(
                      Icons.delete_outline_rounded,
                      size: 16,
                      color: AppColors.midGray,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MedicalInfoCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.lightGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.sosRed.withValues(alpha: 0.05),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.medical_information_rounded,
                  color: AppColors.sosRed,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Medical Information',
                  style: GoogleFonts.inter(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.navyDark,
                  ),
                ),
                const Spacer(),
                Text(
                  'Edit',
                  style: GoogleFonts.inter(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.sosRed,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                InfoRow(
                  label: 'Blood Group',
                  value: 'B+',
                  icon: Icons.bloodtype_rounded,
                ),
                const Divider(color: AppColors.lightGray, height: 1),
                InfoRow(
                  label: 'Allergies',
                  value: 'Penicillin, Pollen',
                  icon: Icons.warning_amber_rounded,
                ),
                const Divider(color: AppColors.lightGray, height: 1),
                InfoRow(
                  label: 'Medical Conditions',
                  value: 'Mild Asthma',
                  icon: Icons.monitor_heart_rounded,
                ),
                const Divider(color: AppColors.lightGray, height: 1),
                InfoRow(
                  label: 'Emergency Note',
                  value: 'Carry Salbutamol inhaler',
                  icon: Icons.note_alt_rounded,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LabeledField extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final String hint;
  final TextInputType keyboard;

  const _LabeledField({
    required this.label,
    required this.ctrl,
    required this.hint,
    this.keyboard = TextInputType.text,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppColors.navyDark,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: keyboard,
          style: GoogleFonts.inter(fontSize: 15),
          decoration: InputDecoration(hintText: hint),
        ),
      ],
    );
  }
}
